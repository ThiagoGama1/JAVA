/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cafeteria;
import java.util.*;
/**
 *
 * @author Thiago
 */
public class Bebida {
    protected String descricao;
    private List<Adicional> adicionais;
    private double precoBase;
  

    

    public Bebida(String nome, double precoBase) {
        this.descricao = nome;
        this.precoBase = precoBase;
        this.adicionais = new ArrayList<>();
    }
    
    public double calcularPreco(){
        double total = precoBase;
        for(Adicional ad : adicionais){
            total += ad.getPreco();
        }
        return total;
    }
    
    public void adicionarAdicional(Adicional a){
        adicionais.add(a);
        System.out.println("Adicional incluso! ");
    }

    public String getDescricao() {
        return descricao;
    }

    @Override
    public String toString() {
        return "Bebida{" + "descricao=" + descricao + ", adicionais=" + adicionais + '}';
    }

    public List<Adicional> getAdicionais() {
        return adicionais;
    }
    
    
    
}
