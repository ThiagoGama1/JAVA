/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.cafeteria;
import java.util. *;
/**
 *
 * @author Thiago
 */

public class Cafeteria {
    public static void main(String[] args) {
        Map<String, Bebida> cardapio = new HashMap<>();
        cardapio.put("capuccino", new Bebida("Capuccino", 6.00));
        cardapio.put("expresso", new Bebida("Cafe Expresso", 2.50));
        cardapio.put("cha", new Bebida("Cha", 3.50));

        Cliente cliente = new Cliente("Thiago", "123.456.789-00");

        Bebida bebida1 = cardapio.get("capuccino");
        bebida1.adicionarAdicional(new Leite());
        bebida1.adicionarAdicional(new Chantilly());

        Bebida bebida2 = cardapio.get("expresso");
        bebida2.adicionarAdicional(new Canela());

        cliente.fazerPedido(bebida1);
        cliente.fazerPedido(bebida2);

        cliente.mostrarResumoPedido();
    }
}

