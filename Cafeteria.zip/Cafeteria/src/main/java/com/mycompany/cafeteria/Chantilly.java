/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cafeteria;

/**
 *
 * @author Thiago
 */
public class Chantilly implements Adicional {
    @Override
    public String getDescricao(){
        return "Chantilly";
    }
    
    @Override
    public double getPreco(){
        return 1.50;
    }
}
