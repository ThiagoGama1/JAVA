/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cafeteria;
import java.util.*;
/**
 *
 * @author Thiago
 */
public class Cliente {
    private String nome;
    private String cpf;
    private List<Bebida> pedido;

    public Cliente(String nome, String cpf) {
        this.nome = nome;
        this.cpf = cpf;
        pedido = new ArrayList<>();
    }
    
    
    public void fazerPedido(Bebida b){
        pedido.add(b);
        System.out.println("Pedido feito! ");
    }
    public void mostrarResumoPedido(){
       double totalPedido = 0;
       
            System.out.println("===== RESUMO DO PEDIDO =====");
            for(Bebida a : pedido){
                System.out.println("Bebida: " + a.getDescricao());
                
                if(a.getAdicionais().isEmpty()){
                    System.out.println("Sem adicionais. ");
                }
                else{
                    System.out.println("Adicionais: ");
                for (Adicional ad : a.getAdicionais()){
                    System.out.println(ad.getDescricao() + " - R$" + ad.getPreco());
            }
                }
                
                double precoBebida = a.calcularPreco();
                System.out.println("Total da bebida: R$" + precoBebida);
                totalPedido += precoBebida;
            }
            System.out.println("===== TOTAL DO PEDIDO: R$" + totalPedido + " =====");
  
    }
    
    
    
    
    
}
