/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.locadora;
import java.util.*;
/**
 *
 * @author Thiago
 */
public class Cliente {
    private String nome;
    private List<Midia> alugueis;

    public Cliente(String nome) {
        this.nome = nome;
        alugueis = new ArrayList<>();
    }
    
    public void alugar(Midia m){
        for(Midia a : alugueis){
            if(m.getTitulo().equalsIgnoreCase(a.getTitulo()) && m.getAnoLancamento() == a.getAnoLancamento()){
                System.out.println("ERRO: Usuario ja esta com esse titulo! ");
                return;
            }
           
        }
        alugueis.add(m);
        System.out.println("Adicionado! ");
    }
    
    public void mostrarResumoAluguel(){
        for(Midia a : alugueis){
            a.exibirResumo();
        }
    }
    
}
