/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.locadora;

/**
 *
 * @author Thiago
 */
public class Filme extends Midia implements Classificavel {
    private String classificacao;
    public Filme(String titulo, int anoLancamento, double precoBase, String classificacao) {
        super(titulo, anoLancamento, precoBase);
        this.classificacao = classificacao;
    }
    
    @Override
    public String getClassificacao(){
        return classificacao;
    }
    
    @Override
    public void exibirResumo() {
        super.exibirResumo();
        System.out.println("======CLASSIFICACAO======");
        System.out.println(getClassificacao());
}

    @Override
    public double calcularValorAluguel(){
        double valorTotal = getPrecoBase();
        double taxa = 2.00;
        if(getAnoLancamento() > 2018){
            valorTotal += taxa;
        }
       
            return valorTotal;
        
        
    }
    @Override
    public String getTipo(){
        return "Filme";
    }
}
