/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.locadora;
import java.util.*;
/**
 *
 * @author Thiago
 */
public class Locadora {
    private String nome;
    private Map<String, Midia> catalogo;

    public Locadora(String nome) {
        this.nome = nome;
        catalogo = new HashMap<>();
    }
    
    public void adicionarMidia(Midia m){
        if(catalogo.containsKey(m.getTitulo())){
            System.out.println("Essa midia ja esta no catalogo! ");
        }
        else{
            catalogo.put(m.getTitulo(), m);
        }
    }
    
    public void removerMidia(Midia m){
        if(catalogo.containsKey(m.getTitulo())){
            catalogo.remove(m.getTitulo());
            System.out.println("Midia removida! ");
        }
        else{
            System.out.println("Essa midia nao esta no catalogo! ");
        }
    }
    
    
    

    public static void main(String[] args) {
    Locadora loc = new Locadora("LocaTop");

    Filme f1 = new Filme("Batman", 2021, 10.0, "12 anos");
    Filme f2 = new Filme("Titanic", 1998, 8.0, "14 anos");
    Serie s1 = new Serie("Stranger Things", 2016, 9.0, 4);

    loc.adicionarMidia(f1);
    loc.adicionarMidia(f2);
    loc.adicionarMidia(s1);

    Cliente cli = new Cliente("Thiago");
    cli.alugar(f1);
    cli.alugar(s1);
    cli.alugar(f1);
    cli.mostrarResumoAluguel();
}

}
