/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.locadora;

/**
 *
 * @author Thiago
 */
public abstract class Midia {
    private String titulo;
    private int anoLancamento;
    private double precoBase;

    public Midia(String titulo, int anoLancamento, double precoBase) {
        this.titulo = titulo;
        this.anoLancamento = anoLancamento;
        this.precoBase = precoBase;
    }
    
    public void exibirResumo() {
        System.out.println("======TIPO======");
        System.out.println(getTipo());
        System.out.println("======TITULO======");
        System.out.println(getTitulo());
        System.out.println("======ANO DE LANCAMENTO======");
        System.out.println(getAnoLancamento());
        System.out.println("======PRECO======");
        System.out.println(calcularValorAluguel());
        System.out.println("\n");
}

    
    public abstract double calcularValorAluguel();
   

    public String getTitulo() {
        return titulo;
    }

    public int getAnoLancamento() {
        return anoLancamento;
    }

    public String getTipo(){
        return "Midia generica ";
    }
    public double getPrecoBase() {
        return precoBase;
    }
    
    
}
