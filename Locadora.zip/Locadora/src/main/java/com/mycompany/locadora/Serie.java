/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.locadora;

/**
 *
 * @author Thiago
 */
public class Serie extends Midia {
    private int temporadas;

    public Serie(String titulo, int anoLancamento, double precoBase, int temporadas) {
        super(titulo, anoLancamento, precoBase);
        this.temporadas = temporadas;
        
    }

    public int getTemporadas() {
        return temporadas;
    }
    
    
    @Override
    public double calcularValorAluguel(){
        double valorTotal = (getPrecoBase() + getTemporadas());
      
        return valorTotal;
    }
    
    @Override
    public String getTipo(){
        return "Serie";
    }
    
    
    
}
