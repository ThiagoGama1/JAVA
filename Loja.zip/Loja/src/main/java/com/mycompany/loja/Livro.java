/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.loja;

/**
 *
 * @author Thiago
 */
public class Livro extends Produto implements Descontavel {

    public Livro(String nome, double precoBase) {
        super(nome, precoBase);
    }
    @Override
    public double getDesconto(){
        return (getPrecoBase() * 0.10);
    }
    @Override
    public double calcularPrecoFinal(){
        return (getPrecoBase() - getDesconto());
    }
    
    @Override
    
    public String getTipo(){
        return "Livro ";
    }
    
    
    
}
