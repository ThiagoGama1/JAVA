/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.loja;
import java.util.*;
/**
 *
 * @author Thiago
 */
public class Loja {
    private String nome;
    private List<Produto> produtos;

    public Loja(String nome) {
        this.nome = nome;
        produtos = new ArrayList<>();
    }

    public String getNome() {
        return nome;
    }

    public List<Produto> getProdutos() {
        return produtos;
    }
    
    
    
    public static void main(String[] args) {
        
        Loja minhaLoja = new Loja("Loja do Thiago");
        
        Produto Livro1 = new Livro("Harry Potter", 15.0);
        Produto Livro2 = new Livro("O Senhor dos Aneis", 10.0);
        
        Produto placaMae = new Eletronico("Placa mae", 900.0); 
        Produto Mouse = new Eletronico("Mouse", 150.0);
        
        minhaLoja.produtos.add(Livro1);
        minhaLoja.produtos.add(Livro2);
        minhaLoja.produtos.add(placaMae);
        minhaLoja.produtos.add(Mouse);
        
        for(Produto a : minhaLoja.getProdutos()){
            System.out.println(a.getTipo());
            System.out.println(a.getNome());
            System.out.println(a.getPrecoBase());
            System.out.println(a.calcularPrecoFinal());
        }
    }
}
