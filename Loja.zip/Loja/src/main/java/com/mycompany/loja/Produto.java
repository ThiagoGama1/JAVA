/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.loja;

/**
 *
 * @author Thiago
 */
public abstract class Produto {
    private String nome;
    private double precoBase;

    public Produto(String nome, double precoBase) {
        this.nome = nome;
        this.precoBase = precoBase;
    }
    
    

    public String getNome() {
        return nome;
    }

    public double getPrecoBase() {
        return precoBase;
    }
    
    public double calcularPrecoFinal(){
        return getPrecoBase();
    }

    @Override
    public String toString() {
        return "Produto{" + "nome=" + nome + ", precoBase=" + precoBase + '}';
    }
    
    public String getTipo(){
        return "Produto generico ";
    }
    
    
    
}
