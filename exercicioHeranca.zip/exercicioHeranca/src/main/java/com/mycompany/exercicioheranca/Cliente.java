/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exercicioheranca;
import java.util.*;
/**
 *
 * @author Thiago
 */
public class Cliente {
    private String nome;
    private String cpf;
    private List<Conta> listaContas;

    public Cliente(String nome, String cpf) {
        this.nome = nome;
        this.cpf = cpf;
        listaContas = new ArrayList<>();
    }
    
    public void adicionarConta(Conta a){
        boolean add = true;
        
        for (Conta b : listaContas){
            if(b.getNumero() == a.getNumero()){
                System.out.println("Conta já existente! ");
                add = false;
                break;
            }
        }
        if(add){
            listaContas.add(a);
        }
    }
    
    public void mostrarSaldos(){
        for (Conta b : listaContas){
                System.out.println("[" + b.getTipo() + "] Número: " + b.getNumero()+ ", Saldo: R$" + b.getSaldo());
            
        }
        
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    @Override
    public String toString() {
        return "Cliente{" + "nome=" + nome + ", cpf=" + cpf + ", listaContas=" + listaContas + '}';
    }
    
    
    
}
