/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exercicioheranca;

/**
 *
 * @author Thiago
 */
public class Conta {
    protected double saldo;
    private int numero;

    public Conta(int numero) {
        this.saldo = 0.0;
        this.numero = numero;
    }

    
    
    public void sacar(double valor){
        if(valor > saldo){
           System.out.println("Valor superior ao seu saldo! "); 
        }
        else{
            saldo -= valor;
            System.out.println("Saque efetuado! ");
        }
    
    
    }
    
    public void depositar(double valor){
        saldo += valor;
        System.out.println("Deposito realizado! ");
    }
    
    public void aplicarRendimento(){
        System.out.println("Conta generica nao aplica rendimento! ");
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }
    public String getTipo(){
        return "Conta generica";
    }
    
    
    @Override
    public String toString() {
        return "Conta{" + "saldo=" + saldo + ", numero=" + numero + '}';
    }
    
    
}
