/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exercicioheranca;

/**
 *
 * @author Thiago
 */
public class ContaCorrente extends Conta {
    
    public ContaCorrente(int numero){
        super(numero);
    }
    
    @Override
    public void sacar(double valor){
        double taxa = 5.0;
        if(valor + taxa > saldo){
           System.out.println("Valor superior ao seu saldo! "); 
        }
        else{
            saldo -= (valor + taxa);
            System.out.println("Saque efetuado com taxa de R$5,00. ");
        }
    }
    
    @Override
    public void aplicarRendimento(){
        double rendimentoCorrente = 1.012;
        saldo *= rendimentoCorrente;
        System.out.println("Rendimento de 1,2% aplicado! ");
    }
    
    
    
    
    @Override
    public String getTipo() {
    return "Corrente";
}
}
